# spec/factories/locations.rb
FactoryBot.define do
    factory :location do
      name { "Test Location" }
      # Add any additional attributes if necessary
    end
end
  