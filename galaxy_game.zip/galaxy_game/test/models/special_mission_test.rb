require "test_helper"

class SpecialMissionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
