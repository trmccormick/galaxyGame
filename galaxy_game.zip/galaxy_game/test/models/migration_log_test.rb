require "test_helper"

class MigrationLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
