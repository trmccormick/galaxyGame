require "test_helper"

class LogisticsContractTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
