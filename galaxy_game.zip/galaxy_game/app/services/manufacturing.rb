module Manufacturing
  # This module contains all manufacturing-related services
end