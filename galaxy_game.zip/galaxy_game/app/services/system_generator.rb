# app/services/system_generator.rb
SystemGenerator = StarSim::ProceduralGenerator