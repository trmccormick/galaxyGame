class GameController < ApplicationController
  def index
    @game_state = GameState.first_or_create!
    @game_state.update_time! if @game_state.running?

    @solar_system = SolarSystem.find_by(name: 'Sol')
    @celestial_bodies = @solar_system.celestial_bodies if @solar_system
  end
end
