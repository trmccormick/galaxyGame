class SolarSystemsController < ApplicationController
end
