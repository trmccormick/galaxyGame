module Units
  # This module contains all unit-related classes
end

# Alias for backward compatibility
Unit = Units::BaseUnit