class Spaceship < ApplicationRecord
    include Mineable
  
    # Spaceship-specific associations and logic go here
end
  
