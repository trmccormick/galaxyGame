module Structures
  def self.table_name_prefix
    "structures_"
  end
end
