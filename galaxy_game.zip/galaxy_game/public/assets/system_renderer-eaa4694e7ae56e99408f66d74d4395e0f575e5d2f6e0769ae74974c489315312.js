// Stub for Sprockets asset pipeline;
