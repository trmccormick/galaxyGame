require 'yaml'

# MATERIALS = YAML.load_file(Rails.root.join('config', 'materials.yml'))['materials'].map do |material|
#   material.with_indifferent_access # Allows for symbol/strings access
# end